def sommeVersString(a: int, b: int) -> str:
    return str(a+b)


a: int = sommeVersString(3, 2)
sommeVersString(3, 2) + sommeVersString(1, 4)
sommeVersString(3, 2)//sommeVersString(1, 4)
